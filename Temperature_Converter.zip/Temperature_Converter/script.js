
function convert() {
	// Get the temperature value
	var temp = document.getElementById("temp").value;
	// Get the "from" unit
	var from = document.getElementById("from").value;
	// Get the "to" unit
	var to = document.getElementById("to").value;

	// Check if the user has entered a valid temperature value
	if (temp === "") {
		alert("Please enter a temperature value");
		return;
	}

	// Check if the "from" and "to" units are the same
	if (from === to) {
		alert("Please select different temperature units");
		return;
	}

	// Convert the temperature value to celsius
	if (from === "fahrenheit") {
		temp = (temp - 32) * 5/9;
	} else if (from === "kelvin") {
		temp = temp - 273.15;
	}
	if (to === "fahrenheit") {
		temp = (temp * 9/5) + 32;
	// Convert to kelvin
	} else if (to === "kelvin") {
		temp = temp + 273.15;
	}
	// Display the result
	document.getElementById("result").innerHTML = temp.toFixed(2) + " " + to.toUpperCase();
}

